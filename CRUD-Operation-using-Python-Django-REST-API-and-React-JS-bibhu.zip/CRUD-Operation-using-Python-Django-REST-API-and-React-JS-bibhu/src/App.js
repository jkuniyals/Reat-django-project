import './App.css';
import PatientList from './components/PatientList'

function App() {
  return (
   <>
   <PatientList />
   </>
  );
}

export default App;
